# Task 001: Bootstrap the ApiaryLens Repository

## Goal

Create the initial repository structure for ApiaryLens without implementing product features yet.

## Scope

Create:

```text
apps/
  web/
  api/
  worker/
  mobile/
packages/
  ui/
  shared/
  database/
  api-client/
docs/
tasks/
docker/
scripts/
.github/
```

Add or preserve:

- README.md
- AGENTS.md
- LICENSE placeholder if missing
- CONTRIBUTING.md
- SECURITY.md
- CODE_OF_CONDUCT.md
- docs/product/product-brief.md
- docs/strategy/domain-strategy.md
- docs/architecture/repository-strategy.md
- docs/architecture/initial-architecture.md
- docs/roadmap/roadmap.md
- docs/adr/0001-project-structure.md

## Requirements

- Do not build the actual app yet.
- Do not choose backend framework yet unless creating placeholder directories only.
- Do not add cloud dependencies.
- Do not add SaaS assumptions.
- Do not remove project docs.
- Create `.gitkeep` files for empty directories if needed.
- Create a clean initial commit message suggestion.

## Completion Criteria

- Repository structure exists.
- Docs exist.
- Codex can explain the repo.
- No product code is implemented yet.
