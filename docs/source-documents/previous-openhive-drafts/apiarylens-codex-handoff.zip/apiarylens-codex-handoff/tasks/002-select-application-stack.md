# Task 002: Select the Application Stack

## Goal

Create ADRs for the initial frontend, backend, database, and deployment stack.

## Required ADRs

- ADR 0002: Frontend stack
- ADR 0003: Backend stack
- ADR 0004: Database and migration strategy
- ADR 0005: PWA/offline-first strategy
- ADR 0006: Authentication strategy
- ADR 0007: Media storage strategy

## Current Preference

Frontend:

- React
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui

Backend candidates:

- FastAPI
- NestJS

Database:

- PostgreSQL

Deployment:

- Docker Compose first

## Do Not

- Implement the app yet.
- Install large dependencies without approval.
- Create SaaS-only architecture.
