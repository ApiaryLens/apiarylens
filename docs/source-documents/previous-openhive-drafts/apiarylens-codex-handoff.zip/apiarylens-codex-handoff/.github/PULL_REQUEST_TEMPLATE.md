## Summary

## Related issue/task

## Changes

## Testing

## Screenshots

## Checklist

- [ ] I followed `AGENTS.md`
- [ ] I updated docs if behavior changed
- [ ] I added or updated tests if applicable
- [ ] I did not introduce required paid cloud services
- [ ] I did not make AI required for core functionality
