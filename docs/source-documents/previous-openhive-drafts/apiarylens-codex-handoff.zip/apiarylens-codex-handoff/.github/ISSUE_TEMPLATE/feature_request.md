---
name: Feature request
about: Suggest a feature for ApiaryLens
title: "[Feature]: "
labels: enhancement
assignees: ""
---

## Summary

## Beekeeping use case

## Proposed behavior

## Alternatives considered

## Additional context
