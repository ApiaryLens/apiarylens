param(
    [string]$Root = "$HOME\source\repos\apiarylens"
)

Write-Host "Creating ApiaryLens local repo at $Root"

New-Item -ItemType Directory -Force -Path $Root | Out-Null
Set-Location $Root

if (-not (Test-Path ".git")) {
    git init
    git branch -M main
}

Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Extract the ApiaryLens handoff zip into this folder."
Write-Host "2. Run: git add ."
Write-Host "3. Run: git commit -m 'docs: seed ApiaryLens project foundation'"
Write-Host "4. Run: codex"
Write-Host "5. Paste the prompt from prompts/codex-initial-prompt.md"
