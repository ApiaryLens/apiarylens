# AGENTS.md

This file provides persistent instructions for AI coding agents working on ApiaryLens.

## Product Identity

The project name is **ApiaryLens**.

ApiaryLens is an open-source, self-hosted apiary intelligence and hive management platform.

Do not rename the product or introduce alternate product names unless the user explicitly asks.

## Core Principles

1. Self-hosted must remain first-class.
2. Offline-first PWA must remain first-class.
3. No required paid cloud services for core operation.
4. AI features must be optional, provider-pluggable, and never required.
5. User data belongs to the user and must be exportable.
6. The app must scale from 1 hive to 100+ hives.
7. UI must be usable outdoors, on mobile, with gloves, and under sun glare.
8. Every major feature must be documented before implementation.
9. Prefer simple, maintainable architecture over clever complexity.
10. When unsure, create an ADR instead of silently changing architecture.

## Current Architecture Direction

Start as a monorepo:

```text
apps/
  web/
  api/
  worker/
packages/
  ui/
  shared/
  database/
  api-client/
docs/
tasks/
docker/
scripts/
.github/
```

## Development Expectations

- Use TypeScript where practical.
- Keep backend and frontend contracts documented.
- Add tests for meaningful logic.
- Avoid speculative features unless they are in the task.
- Do not introduce SaaS-only dependencies.
- Do not require OpenAI, Anthropic, Google, AWS, Azure, or any paid API for core use.
- Prefer local filesystem storage first; make S3-compatible storage optional later.
- Make all AI integrations optional and disabled by default.

## Beekeeping Domain Rules

The application should support:

- Multiple organizations
- Multiple apiaries
- Multiple hives
- Hive components: boxes, frames, bottom boards, covers, feeders, queen excluders
- Queen tracking
- Inspections
- Photos and videos
- Mite counts
- Treatments
- Feeding
- Weather history
- Bloom/forage calendar
- Honey harvests
- Mentors and sharing
- Future sensors and Home Assistant integration

## Safety and Health Notes

AI image analysis may flag possible observations, but it must not present itself as a definitive disease diagnosis.

Use phrasing such as:

> "Possible issue detected. Review with an experienced beekeeper, mentor, inspector, or extension office."

Do not build features that encourage unsafe pesticide/treatment use without dosage restrictions, label warnings, and user confirmation.

## Codex Workflow

Before coding:

1. Read the assigned task under `tasks/`.
2. Read relevant docs under `docs/`.
3. Summarize the intended change.
4. Make focused changes only.
5. Run available tests/build checks.
6. Summarize changed files and next steps.

Do not implement multiple roadmap phases in one task.
