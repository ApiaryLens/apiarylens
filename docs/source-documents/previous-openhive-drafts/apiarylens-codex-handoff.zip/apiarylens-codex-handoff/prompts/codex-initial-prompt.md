Read `AGENTS.md`, `README.md`, and the docs under `docs/`.

Then complete only `tasks/001-bootstrap-repository.md`.

Do not implement application features yet. Do not select frameworks yet unless creating placeholder directories. Keep this as a repository foundation commit.

After making changes, summarize:
1. What you created
2. Any assumptions
3. Suggested initial commit message
4. What task should come next
