# Code of Conduct

ApiaryLens should be welcoming to new beekeepers, experienced beekeepers, developers, researchers, and community contributors.

Be respectful, helpful, and constructive.
