# Contributing to ApiaryLens

ApiaryLens is early-stage.

Before contributing:

1. Read `README.md`
2. Read `AGENTS.md`
3. Read `docs/product/product-brief.md`
4. Pick or create a task under `tasks/`

Do not submit large, unfocused changes.
