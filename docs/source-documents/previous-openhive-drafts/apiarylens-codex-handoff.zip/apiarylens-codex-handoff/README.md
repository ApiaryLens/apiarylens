# ApiaryLens

**ApiaryLens** is an open-source, self-hosted apiary intelligence and hive management platform.

ApiaryLens is designed for:
- New beekeepers managing their first hive
- Families learning beekeeping together
- Bee clubs and mentors
- Commercial apiaries
- Extension offices and educators
- Researchers and sensor/AI experimentation

## Current Product Direction

ApiaryLens is not a SaaS product at launch.

The launch direction is:

- Open source first
- Self-hosted first
- Offline-first PWA
- Privacy-first
- AI-assisted, but not AI-dependent
- Community-driven
- SaaS-capable later

## Initial Technology Direction

- Frontend: React + TypeScript + Vite
- UI: Tailwind CSS + shadcn/ui
- Mobile/PWA: PWA first, Capacitor later for iOS/Android
- Backend: FastAPI or NestJS, final decision pending ADR
- Database: PostgreSQL
- Storage: Local filesystem first, S3-compatible optional later
- Deployment: Docker Compose first
- Future: Kubernetes, Helm, hosted SaaS

## Domains

ApiaryLens owns:

- apiarylens.org
- apiarylens.com
- apiarylens.app
- apiarylens.dev

See `docs/strategy/domain-strategy.md`.

## First Codex Task

Open this repo in Codex and ask it to read:

- `AGENTS.md`
- `docs/product/product-brief.md`
- `docs/roadmap/roadmap.md`
- `tasks/001-bootstrap-repository.md`

Then have Codex implement Task 001 only.
