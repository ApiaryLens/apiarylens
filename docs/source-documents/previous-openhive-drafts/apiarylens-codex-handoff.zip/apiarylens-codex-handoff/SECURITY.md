# Security Policy

ApiaryLens is early-stage.

Please do not publicly disclose security vulnerabilities before maintainers have time to review and respond.

Core principles:

- User data belongs to the user.
- Self-hosted deployments must be secure by default.
- AI providers are optional.
- Secrets must never be committed.
