# Repository Strategy

## Initial GitHub Organization

Organization: `ApiaryLens`

## Initial Repositories

Start with three repositories:

```text
.github
apiarylens
apiarylens.org
```

## Repository 1: .github

Purpose:

- Organization profile README
- Community defaults
- Issue templates
- Pull request template
- Security policy
- Code of conduct
- Funding metadata

## Repository 2: apiarylens

Purpose:

Main product monorepo.

Recommended structure:

```text
apiarylens/
├── apps/
│   ├── web/
│   ├── api/
│   ├── worker/
│   └── mobile/
├── packages/
│   ├── ui/
│   ├── shared/
│   ├── database/
│   └── api-client/
├── docs/
├── tasks/
├── docker/
├── scripts/
├── .github/
├── AGENTS.md
├── README.md
└── LICENSE
```

## Repository 3: apiarylens.org

Purpose:

Public website and documentation site.

Recommended tooling:

- Docusaurus, Astro, or VitePress
- GitHub Pages or Cloudflare Pages

## Repositories to Delay

Do not create these yet:

```text
apiarylens-api
apiarylens-web
apiarylens-mobile
apiarylens-cloud
apiarylens-plugins
apiarylens-sensors
apiarylens-helm
```

Split them later only when operational need exists.
