# Initial Architecture

## Architecture Style

ApiaryLens starts as a modular monorepo with independently deployable application components.

## Proposed Runtime Components

```text
Browser / PWA / Future Mobile App
        |
        v
Web Frontend
        |
        v
Backend API
        |
        +--> PostgreSQL
        +--> Local/S3-compatible object storage
        +--> Worker queue
        +--> Weather provider adapters
        +--> Optional AI provider adapters
```

## Frontend

Initial proposal:

- React
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- PWA support
- Offline-first local persistence
- Capacitor later for iOS/Android

## Backend

Candidate options:

- FastAPI
- NestJS

Decision should be recorded in an ADR before implementation.

## Database

Initial proposal:

- PostgreSQL
- Multi-tenant-ready schema using organizations
- Migration system required from day one

Core entities:

- Organization
- User
- Membership
- Apiary
- Hive
- HiveComponent
- Box
- Frame
- Queen
- Inspection
- MediaAsset
- MiteCount
- Treatment
- Feeding
- Harvest
- WeatherRecord
- BloomRecord
- ShareLink

## Storage

Start with local filesystem storage.

Design for optional S3-compatible storage later.

Potential future providers:

- MinIO
- Backblaze B2
- Cloudflare R2
- AWS S3
- Azure Blob via S3 gateway or adapter

## AI

AI features are optional.

Provider adapters should allow:

- OpenAI
- Anthropic
- Local model
- Disabled/offline mode

AI output must be stored as observations and never as authoritative diagnosis.

## Deployment

MVP deployment target:

```text
docker compose up -d
```

Future:

- Kubernetes
- Helm chart
- Hosted SaaS
