# ADR 0001: Start with a Monorepo

## Status

Proposed

## Context

ApiaryLens needs to move quickly while keeping frontend, backend, shared types, database migrations, docs, and tasks aligned.

Starting with many repositories would create operational overhead too early.

## Decision

Start with a monorepo named `apiarylens`.

Initial structure:

```text
apps/
  web/
  api/
  worker/
  mobile/
packages/
  ui/
  shared/
  database/
  api-client/
docs/
tasks/
docker/
scripts/
.github/
```

## Consequences

Benefits:

- Easier for Codex and other agents to understand the full project.
- Easier shared types and API contract generation.
- Easier local development.
- Easier early refactoring.

Tradeoffs:

- Repo may grow large over time.
- CI must be designed carefully.
- Future splits may be needed for mobile, sensors, plugins, or SaaS.
