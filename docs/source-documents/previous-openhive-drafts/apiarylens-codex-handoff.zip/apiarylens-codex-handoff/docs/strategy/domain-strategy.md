# ApiaryLens Domain Strategy

ApiaryLens owns:

- `apiarylens.org`
- `apiarylens.com`
- `apiarylens.app`
- `apiarylens.dev`

## apiarylens.org

Primary open-source project home.

Uses:

- Project website
- Public docs
- Install guide
- Roadmap
- Community
- GitHub links
- Family/friends overview
- Bee club onboarding

Recommended DNS:

```text
apiarylens.org
www.apiarylens.org
docs.apiarylens.org
demo.apiarylens.org
```

## apiarylens.com

Reserved for defensive/commercial ownership.

Early behavior:

```text
apiarylens.com -> apiarylens.org
www.apiarylens.com -> apiarylens.org
```

Future possible use:

- Commercial landing page
- Hosted SaaS
- Support plans
- Sponsors
- Partner marketplace

## apiarylens.app

Reserved for the future app/PWA identity.

Possible uses:

- Hosted app entry point
- PWA landing page
- Mobile app landing page
- SaaS login portal
- Demo app

Early behavior:

```text
apiarylens.app -> apiarylens.org
```

## apiarylens.dev

Reserved for developer ecosystem.

Possible uses:

- API docs
- SDK docs
- Plugin docs
- Contributor docs
- ADRs
- Development environment guides

Possible DNS:

```text
apiarylens.dev
api.apiarylens.dev
sdk.apiarylens.dev
plugins.apiarylens.dev
```

## Positioning

At launch:

```text
Open source first.
Self-hosted first.
Offline-first.
SaaS-capable later.
```
