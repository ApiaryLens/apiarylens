# ApiaryLens Product Brief

## One-Line Description

ApiaryLens is an open-source apiary intelligence platform for tracking hives, inspections, queens, health, weather, blooms, photos, and production from one backyard hive to large-scale operations.

## Mission

Help beekeepers understand, manage, and improve their colonies using practical records, visual history, weather context, health tracking, and optional AI assistance.

## Target Users

### New Beekeeper
Needs simple inspection checklists, reminders, mentor sharing, and basic hive history.

### Family Beekeeper
Needs shared access, easy mobile logging, photos, and task reminders.

### Bee Club
Needs mentor sharing, club apiaries, educational records, and beginner-friendly workflows.

### Commercial Beekeeper
Needs multi-apiary tracking, production reports, queen performance, health records, and inventory.

### Research / Extension
Needs structured records, exportable data, disease observations, weather history, and possibly sensor integration.

## MVP Capabilities

- User accounts and organizations
- Apiaries and hives
- Hive boxes and equipment configuration
- Queen tracking
- Inspections
- Photos/video history
- Varroa mite count tracking
- Disease/pest observation tracking
- Feeding records
- Treatment records
- Honey harvest records
- Weather forecast and historical weather storage
- Bloom/forage calendar foundation
- Basic sharing with mentors/family
- Docker Compose deployment
- PWA support
- Data export

## Future Capabilities

- AI image review for brood, queen, pests, and possible health concerns
- Native iOS and Android apps using Capacitor
- Bee club collaboration
- Plugin system
- Home Assistant integration
- Hive scales and sensors
- Route planning
- Honey sales/inventory
- Research mode
- SaaS-hosted option
