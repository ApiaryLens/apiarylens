FROM node:24.18.0-alpine AS build
WORKDIR /workspace
RUN corepack enable
COPY package.json pnpm-lock.yaml pnpm-workspace.yaml tsconfig.base.json ./
COPY apps/web/package.json apps/web/package.json
COPY packages/contracts/package.json packages/contracts/package.json
RUN pnpm install --frozen-lockfile
COPY apps/web apps/web
COPY packages/contracts packages/contracts
RUN pnpm --filter @apiarylens/web build

FROM caddy:2.10.2-alpine
LABEL org.opencontainers.image.title="ApiaryLens PWA" \
      org.opencontainers.image.version="0.1.0-rc.1" \
      org.opencontainers.image.licenses="Apache-2.0"
COPY docker/Caddyfile /etc/caddy/Caddyfile
COPY --from=build /workspace/apps/web/dist /srv
EXPOSE 80 443
