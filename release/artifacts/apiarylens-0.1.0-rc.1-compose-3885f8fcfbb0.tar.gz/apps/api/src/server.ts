import { serve } from '@hono/node-server';
import { SqliteStore } from '@apiarylens/database';
import { FilesystemMediaStore } from '@apiarylens/media';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { createApi } from './app.js';

const port = Number(process.env.PORT ?? 3000);
const databasePath = process.env.APIARYLENS_DATABASE ?? './data/apiarylens.sqlite';
const mediaPath = process.env.APIARYLENS_MEDIA ?? './data/media';
if (databasePath !== ':memory:') mkdirSync(dirname(databasePath), { recursive: true });
const store = new SqliteStore(databasePath);
const mediaStore = new FilesystemMediaStore(mediaPath);
const app = createApi({ store, mediaStore, secureCookies: process.env.NODE_ENV === 'production' });

serve({ fetch: app.fetch, port }, (info) => {
  console.log(`ApiaryLens API listening on http://127.0.0.1:${info.port}`);
});
